# Technical Field Guide v0.3

This package is the machine-readable implementation protocol for the five
worked artefacts in Part IV of *The End of Alignment*. Field Guide v0.3 is the
current companion to book v1.1.5. The two publications use independent version
numbers because a prose revision does not change an artefact contract.

## What is here

```text
schemas/       JSON Schema 2020-12 contracts
protocols/     generic evidence envelope and artefact change mechanics
rules/         core validation rule set 2.0.0
instances/     minimum, complete, evidence, and deliberately broken examples
validation/    the dated result produced by the validator
validate.py    schema and cross-artefact validation
```

The files are authoritative. The public PDF listings and source archive are
generated from this directory; the typeset listings are for reading.

## Run the validator

With Python 3.11 or later:

```sh
python -m pip install -r requirements.txt
python validate.py --write-results
```

The command exits non-zero if a schema fails, a core `error` rule fails, or a
deliberately broken fixture is not detected as documented. A `warn` result is
reported without blocking the package.

The published v0.3 run has no error failures. W003 warns that the two open
worked drift findings are past their recorded dates. Three broken fixtures are
caught by V004, V013, and V021. The fourth records a known gap: V018 does not
resolve reserved-right holders against an institutional register.

The validation record names the rule-set and schema versions and carries a
canonical digest of the validator and every validation input. The PDF also
records the SHA-256 digest of the exact source archive distributed with it.

## Scope

This version does not cover reader tooling or migration mechanics. Both depend
on choices a company has not yet made and would turn a portable protocol into a
premature toolchain.

This package is publicly readable and downloadable. No reuse licence is granted
yet. A standalone repository should not be published until the owner has made
and recorded the software and documentation licence decision.
